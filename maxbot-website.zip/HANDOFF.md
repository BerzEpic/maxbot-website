# Maxbot website — Free and Pro correction

## Current website scope

The website now presents **Free and Pro only**. The documentation hub has Free and Pro cards and a separate WhatsApp Add-on guide. All paid-product buttons open the **Pro** launch-notification form.

The supplied full-builder documentation now appears at `/docs-pro`, following the clarified current Pro product mapping. `/docs-core` remains a compatibility entry and retains every original section anchor. Pro’s website checkout remains unavailable, with monthly Freemius distribution described as planned. No new Pro features, release dates, prices or billing implementation were introduced.

Removed the excluded edition from navigation, cards, comparisons, homepage statistics, footer, documentation, privacy copy, page titles/descriptions, client scripts, configuration and server-side form acceptance. The obsolete guide file is replaced with a redirect to `/docs`; it must overwrite the previous file when deploying over the earlier package. No public links point to it.

## Routes

All routes are relative to `/landing/maxbot`:

| Route | Result |
| --- | --- |
| `/docs` | Free and Pro hub plus separate WhatsApp guide |
| `/docs-free` | Complete Free setup-to-publishing guide |
| `/docs-pro` | Full Pro builder guide |
| `/docs-core` | Compatibility entry to the same Pro guide, with its anchors intact |
| `/docs-whatsapp` | Existing add-on guide and anchors |
| `/#licensing`, `/features#licensing` | Free and Pro edition models |

Free documentation still follows the source-verified `maxbot-core-3.0.30.zip` implementation: Welcome → Intended use → Agent → Project setup → Build and save → Test Flow → Email notifications → Stay in touch → Enable chatbot. Its four selectable notification events, explicit conversation-close behavior, single Agent/Project/flow interface, requirements and integration availability are unchanged.

Advanced templates, cards, data capture and tutorial examples are now identified with the current Pro builder. Free instructions remain separate. The existing widget, template assets and preview views are unchanged. No plugin or API reference package was edited.

## Lead integration: remaining blocker

Signup remains disabled until the existing Free API supports the website’s minimal Pro launch request. Leave `MAXBOT_LAUNCH_CONFIG_FILE` unset.

The available `maxbot-saas-rest-api-free-cleanup.zip` source confirms:

- Fixed public endpoint: `https://climaxweb.net/rest-free/api/v1/leads`.
- No installation credential, purchase code or private API key is required for lead creation.
- The v1 form requires exactly name, email, intended_use, product_interests, consent and consent_version. Name must be nonempty.
- The v2 tutorial contract allows an empty name but additionally requires setup_answers.
- The accepted consent versions are `maxbot-tutorials-v1` and `maxbot-tutorials-v2`; neither describes a Pro-launch-only request.
- `pro` is already an accepted product interest. This does **not** solve the consent/required-field problems.
- Duplicate contacts are preserved using insertOrIgnore; previous interests, consent and opt-outs are not overwritten. An `accepted` response can therefore refer to an older record without recording new Pro launch interest.
- Responses use success/code/data envelopes. Validation returns 422; unavailable signup returns 503; the lead route has a six-per-minute IP limit and may return 429. Existing opt-outs can return data.status=unsubscribed.
- Signup records contacts immediately without a new confirmation or welcome-email workflow.

The website must not fabricate a name, intended use or setup answers, reuse tutorial consent for a launch-only checkbox, or claim that an old accepted contact has newly registered Pro interest.

Before enabling, extend/review the existing service’s contract for minimal Pro launch consent and privacy-preserving repeat-contact handling. Then copy `config/launch.example.php` outside the public document root and supply reviewed `build_payload` and `confirms_launch_consent` callbacks for Pro. Set `MAXBOT_LAUNCH_CONFIG_FILE` to that absolute path and enable only after staging verification. A bare accepted response is insufficient proof.

The adapter already provides authoritative input validation, Pro-only request acceptance, fixed-destination HTTPS transport, no redirects, bounded payloads, request limiting and honest error mapping. It does not expose credentials, store email in browser storage, log raw contact details, create installations, send mail or introduce a second lead store. A writable private system temporary directory is needed for hashed-IP rate counters, and PHP cURL is needed when enabled. Behind a proxy, configure trusted client-IP handling at the server; arbitrary forwarded headers are not trusted. The backend’s IP limit may aggregate proxied website traffic under the website server’s address.

## Validation

- 40 PHP files passed PHP 8.3.6 syntax validation; both marketing JavaScript files passed Node syntax checks.
- 44 mocked adapter assertions passed, including Pro-only acceptance, validation, disabled configuration, duplicate/opt-out handling, failure states and rate limits.
- 698 browser/HTTP assertions passed in Chromium at 1440px and 390px. Checks cover 14 page routes, Pro CTAs, dialog behavior, mobile navigation, no overflow, links/anchors, absence of excluded-edition copy and metadata, retired-guide redirect, server validation and mocked signup outcomes.
- The updated documentation hub was visually inspected. All 45 original full-builder section anchors and all 27 WhatsApp section anchors remain available.
- Both patch baselines are verified during packaging; each patch must reproduce the complete output ZIP content exactly.
- Browser success/error outcomes for enabled signup are mocked; no live visitors or production emails were submitted.

External requests are blocked in the browser fixture. The unchanged embedded template preview depends on an external jQuery CDN and reports two expected missing-jQuery errors in that fixture; its live runtime is not validated. Changed marketing/form code must have no unexpected errors. Apache/Hostinger configuration, actual WordPress runtime, real mail/push/WhatsApp delivery, Safari/iOS and a full screen-reader audit remain outside these checks.

## Apply the correct patch

- `maxbot-website-free-pro-update.patch`: apply to the **previous website ZIP delivered in this conversation**.
- `maxbot-website-editions.patch`: cumulative patch against the **original supplied website ZIP**.
- `maxbot-website-updated.zip`: complete corrected website; includes all source/assets and the obsolete-page redirect.

Use only the patch matching your current baseline. From the website root:

```sh
git apply --check maxbot-website-free-pro-update.patch
git apply maxbot-website-free-pro-update.patch
```

The ZIP excludes `.git`, credentials, real `.env` files, node_modules and temporary verification files. Nothing has been deployed.
