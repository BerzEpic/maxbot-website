<?php
/** Product direction, availability and actions live here, independently of features. */
function mb_editions(): array
{
    return [
        'free' => ['name' => 'Maxbot Free', 'channel' => 'WordPress.org', 'billing' => 'Free · no monthly subscription',
            'status' => 'Listing to be announced', 'docs' => 'docs-free', 'checkout' => ''],
        'pro' => ['name' => 'Maxbot Pro', 'channel' => 'This website, using Freemius', 'billing' => 'Monthly subscription',
            'status' => 'Coming soon', 'docs' => 'docs-pro', 'checkout' => ''],
    ];
}

function mb_edition_cta(string $edition, string $class = 'btn btn--primary', ?string $label = null): string
{
    $item = mb_editions()[$edition] ?? null;
    if (!$item || $edition !== 'pro') {
        throw new InvalidArgumentException('Only Pro has a launch notification action.');
    }
    return '<button type="button" class="' . mb_e($class) . '" data-launch-edition="' . mb_e($edition)
        . '" aria-haspopup="dialog">' . mb_e($label ?? ('Notify me about ' . $item['name'])) . '</button>';
}
