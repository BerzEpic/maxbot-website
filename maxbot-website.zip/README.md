# Maxbot website — Free and Pro

This website presents **Maxbot Free** and **Maxbot Pro** only, with a separate WhatsApp Add-on guide. Pro documentation describes the current full builder. Pro checkout is coming soon; paid-product actions open the Pro launch-notification form.

The application uses plain PHP, authored CSS and dependency-free marketing JavaScript. No framework or asset-build step is required. Existing widget, template-preview and template assets remain unchanged.

## Run locally

```sh
php -S 127.0.0.1:8082 tests/router.php
```

Open `http://127.0.0.1:8082/landing/maxbot/`. Production uses Apache `.htaccess` with mod_rewrite. PHP cURL is required when the reviewed lead adapter is enabled.

## Documentation routes

| Route | Purpose |
| --- | --- |
| `/docs` | Free and Pro documentation hub, plus WhatsApp Add-on |
| `/docs-free` | Free 3.0.30 setup-to-publishing guide |
| `/docs-pro` | Current Pro builder documentation |
| `/docs-core` | Compatibility URL for the Pro guide; all existing anchors preserved |
| `/docs-whatsapp` | Separate add-on guide; existing anchors preserved |
| `/features#licensing`, `/#licensing` | Free and Pro distribution/billing |

The obsolete edition guide redirects to `/docs` and contains no product copy. Its small redirect file must replace the previous page when updating an existing installation.

## Configuration

- `config.php`: install path, existing demo identifiers and privacy contact.
- `.htaccess`: if moving the installation, update RewriteBase and redirect prefixes together with `APP_BASE_URL`.
- `src/Editions.php`: only Free and Pro are defined. Free is planned for WordPress.org, without a monthly subscription. Pro is planned for this website using Freemius with a monthly subscription. Checkout is not implemented.
- `MAXBOT_LAUNCH_CONFIG_FILE`: optional absolute path to a reviewed PHP contract file outside the public document root. **Leave unset for now.** See `config/launch.example.php` and `HANDOFF.md` for the existing API contract and remaining launch-consent blocker.

The lead adapter only accepts Pro launch requests. Missing configuration returns an honest 503; it never reports an unsubmitted request as successful. The existing WhatsApp product destination is separate and unchanged.

## Checks

```sh
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check static/js/maxbot.js
node --check static/js/launch.js
php tests/launch-interest-test.php
```

With Playwright and Chromium installed, run `node tests/browser.cjs`. It starts/stops a local PHP server and supports `PHP_BIN`, `PLAYWRIGHT_MODULE`, `CHROMIUM_BIN` and `SCREENSHOT_DIR`. Enabled signup responses are mocked; the script never posts to the live leads service.

## Packaging

Deploy source and assets, including `.htaccess`. Do not include `.git`, real `.env` files, credentials, local configuration, node_modules or temporary runtime downloads. Maintainer/config/test paths are blocked by `.htaccess`. No generated bundle has been changed.

See `HANDOFF.md` for patch baselines, source verification and validation limitations.
